
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Github } from "lucide-react";

const Projects = () => {
  const projects = [
    {
      title: "Software Behaviour Prediction",
      description: "Real-time prediction of software issues using NLP and deep learning. Built with LSTM networks and deployed as a Flask web application.",
      techStack: ["LSTM", "Flask", "Python", "NLP", "Deep Learning"],
      achievements: [
        "Achieved 88% prediction accuracy",
        "Real-time issue detection",
        "Integrated with CI/CD pipelines"
      ],
      github: "https://github.com/sivapalla2003/Software-Behaviour-Predictor",
      featured: true
    },
    {
      title: "Sentiment Analysis System",
      description: "Comprehensive sentiment analysis tool built using Naive Bayes and LSTM models with real-world data insights and visualization.",
      techStack: ["Naive Bayes", "LSTM", "Python", "Pandas", "Matplotlib"],
      achievements: [
        "Multi-model comparison",
        "Real-world data insights",
        "Interactive visualizations"
      ],
      github: "https://github.com/sivapalla2003/SentimentDetectionAnalyzer",
      featured: true
    },
    {
      title: "SMS Spam Detection",
      description: "Advanced spam detection system using SVM and Logistic Regression with feature engineering and text preprocessing.",
      techStack: ["SVM", "Logistic Regression", "Scikit-Learn", "NLTK"],
      achievements: [
        "90%+ accuracy achieved",
        "Real-time classification",
        "Robust preprocessing pipeline"
      ],
      github: "https://github.com/sivapalla2003/Email-SMS-Spam-Classifier-",
      featured: true
    }
  ];

  const handleGithubClick = (url: string) => {
    console.log('Opening GitHub repository:', url);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">Featured Projects</h2>
          <p className="text-xl text-slate-600">Showcasing my technical expertise and problem-solving skills</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {projects.filter(p => p.featured).map((project, index) => (
            <Card key={index} className="hover:shadow-xl transition-all duration-300 border-t-4 border-t-teal-500">
              <CardContent className="p-8">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl font-bold text-slate-900 mb-3">
                      {project.title}
                    </h3>
                    <p className="text-slate-600 leading-relaxed">
                      {project.description}
                    </p>
                  </div>

                  <div>
                    <h4 className="font-semibold text-slate-800 mb-3">Key Achievements</h4>
                    <ul className="space-y-2">
                      {project.achievements.map((achievement, idx) => (
                        <li key={idx} className="text-slate-600 flex items-start gap-2">
                          <span className="w-2 h-2 bg-teal-500 rounded-full mt-2 flex-shrink-0"></span>
                          {achievement}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-slate-800 mb-3">Tech Stack</h4>
                    <div className="flex flex-wrap gap-2">
                      {project.techStack.map((tech, idx) => (
                        <Badge key={idx} variant="secondary" className="bg-slate-100 text-slate-700">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="pt-4">
                    <Button 
                      onClick={() => handleGithubClick(project.github)}
                      className="bg-teal-600 hover:bg-teal-700 flex items-center gap-2"
                    >
                      <Github size={16} />
                      Source Code
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Other Projects */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.filter(p => !p.featured).map((project, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-slate-900 mb-3">
                  {project.title}
                </h3>
                <p className="text-slate-600 text-sm mb-4">
                  {project.description}
                </p>
                
                <div className="flex flex-wrap gap-1 mb-4">
                  {project.techStack.slice(0, 3).map((tech, idx) => (
                    <Badge key={idx} variant="secondary" className="text-xs">
                      {tech}
                    </Badge>
                  ))}
                </div>

                <Button 
                  onClick={() => handleGithubClick(project.github)}
                  className="w-full bg-teal-600 hover:bg-teal-700 flex items-center justify-center gap-2"
                >
                  <Github size={14} />
                  Source Code
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Projects;
