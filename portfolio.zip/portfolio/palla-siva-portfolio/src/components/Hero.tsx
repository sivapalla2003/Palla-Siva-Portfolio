import { Button } from "@/components/ui/button";
import { Github, Linkedin, Mail, Download, ArrowDown, Sparkles } from "lucide-react";
import { downloadResume } from "@/utils/resumeGenerator";
import { downloadPortfolioCV } from "@/utils/portfolioPdfGenerator";

const Hero = () => {
  const scrollToAbout = () => {
    const aboutElement = document.getElementById("about");
    if (aboutElement) {
      aboutElement.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleDownloadCV = () => {
    downloadPortfolioCV();
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 pt-16 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-teal-400/5 rounded-full blur-2xl animate-pulse delay-500"></div>
      </div>

      {/* Floating particles */}
      <div className="absolute inset-0">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-teal-400/30 rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 2}s`
            }}
          ></div>
        ))}
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-16">
          {/* Text Content */}
          <div className="flex-1 text-center lg:text-left space-y-8">
            {/* Greeting badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full text-teal-400 text-sm font-medium animate-fade-in">
              <Sparkles className="w-4 h-4" />
              Welcome to my portfolio
            </div>

            <div className="space-y-6">
              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white leading-tight animate-fade-in">
                Hello, I'm
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-teal-400 via-blue-400 to-teal-300 animate-pulse">
                  Palla Siva
                </span>
              </h1>
              
              <div className="space-y-4">
                <p className="text-2xl sm:text-3xl text-slate-300 font-semibold animate-fade-in delay-200">
                  AI Enthusiast | Prompt Engineer
                </p>
                <p className="text-xl sm:text-2xl text-teal-400 font-medium animate-fade-in delay-300">
                  Generative AI Explorer
                </p>
              </div>
              
              <p className="text-lg text-slate-400 max-w-2xl leading-relaxed animate-fade-in delay-500">
                BTech in AI & Data Science with a passion for prompt engineering, 
                Python programming, and generative AI. Building the future one algorithm at a time.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start animate-fade-in delay-700">
                <Button 
                  onClick={scrollToAbout}
                  size="lg"
                  className="bg-gradient-to-r from-teal-600 to-teal-700 hover:from-teal-700 hover:to-teal-800 text-white px-8 py-4 text-lg font-semibold shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300 group"
                >
                  Know More
                  <ArrowDown className="ml-2 h-5 w-5 group-hover:animate-bounce" />
                </Button>
                
                <Button 
                  onClick={handleDownloadCV}
                  variant="outline" 
                  size="lg"
                  className="border-2 border-teal-400/30 bg-white/5 backdrop-blur-sm text-teal-400 hover:bg-teal-400 hover:text-slate-900 px-8 py-4 text-lg font-semibold shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300 group"
                >
                  <Download className="mr-2 h-5 w-5 group-hover:animate-pulse" />
                  Download CV
                </Button>
              </div>
              
              {/* Social Links */}
              <div className="flex gap-6 justify-center lg:justify-start pt-8 animate-fade-in delay-1000">
                {[
                  { href: "https://linkedin.com", icon: Linkedin, label: "LinkedIn" },
                  { href: "https://github.com", icon: Github, label: "GitHub" },
                  { href: "mailto:pallasiva85636@gmail.com", icon: Mail, label: "Email" }
                ].map(({ href, icon: Icon, label }) => (
                  <a 
                    key={label}
                    href={href} 
                    className="group relative p-3 bg-white/5 backdrop-blur-sm border border-white/10 rounded-full text-slate-400 hover:text-teal-400 hover:bg-teal-400/10 transition-all duration-300 transform hover:scale-110"
                    aria-label={label}
                  >
                    <Icon size={24} className="transition-transform duration-300 group-hover:scale-110" />
                    <div className="absolute -bottom-12 left-1/2 transform -translate-x-1/2 px-2 py-1 bg-slate-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      {label}
                    </div>
                  </a>
                ))}
              </div>
            </div>
          </div>
          
          {/* Profile Picture */}
          <div className="flex-shrink-0 animate-fade-in delay-300">
            <div className="relative group">
              {/* Main profile container with glassmorphism */}
              <div className="w-80 h-80 sm:w-96 sm:h-96 rounded-full bg-gradient-to-br from-teal-400/20 to-blue-500/20 p-1 backdrop-blur-sm border border-white/10 shadow-2xl">
                <div className="w-full h-full rounded-full bg-gradient-to-br from-slate-800/80 to-slate-900/80 backdrop-blur-sm flex items-center justify-center border border-white/5 group-hover:scale-105 transition-transform duration-500 overflow-hidden">
                  <img 
                    src="https://i.postimg.cc/R05K0XnB/1739628757400.jpg"
                    alt="Palla Siva"
                    className="w-full h-full object-cover rounded-full"
                  />
                </div>
              </div>
              
              {/* Floating badges */}
              <div className="absolute -top-6 -right-6 bg-gradient-to-r from-white to-slate-50 rounded-2xl px-6 py-3 shadow-2xl border border-white/20 backdrop-blur-sm animate-bounce">
                <div className="text-center">
                  <div className="text-3xl font-bold bg-gradient-to-r from-slate-900 to-slate-700 bg-clip-text text-transparent">1+</div>
                  <div className="text-sm text-slate-600 font-medium">Years Experience</div>
                </div>
              </div>
              
              <div className="absolute -bottom-6 -left-6 bg-gradient-to-r from-teal-500 to-teal-600 rounded-2xl w-20 h-20 flex items-center justify-center shadow-2xl animate-pulse group-hover:animate-spin">
                <span className="text-white font-bold text-lg">AI</span>
              </div>

              {/* Tech stack orbiting elements */}
              <div className="absolute inset-0 animate-spin" style={{ animationDuration: '20s' }}>
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-lg">
                  PY
                </div>
              </div>
              <div className="absolute inset-0 animate-spin" style={{ animationDuration: '25s', animationDirection: 'reverse' }}>
                <div className="absolute top-1/2 -right-4 transform -translate-y-1/2 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-lg">
                  PP
                </div>
              </div>
              <div className="absolute inset-0 animate-spin" style={{ animationDuration: '30s' }}>
                <div className="absolute bottom-1/4 -left-4 transform w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-lg">
                  GEN
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="flex flex-col items-center text-slate-400">
          <span className="text-sm mb-2">Scroll to explore</span>
          <ArrowDown className="w-5 h-5 animate-pulse" />
        </div>
      </div>
    </div>
  );
};

export default Hero;
