import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { Mail, LinkedinIcon, Github, Phone, MapPin, Send, Loader2 } from "lucide-react";
import emailjs from '@emailjs/browser';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);

    try {
      // Initialize EmailJS with your public key
      emailjs.init('z5tidZShJSzp7Zn7X');

      // EmailJS configuration
      const serviceId = 'service_zotr4mv';
      const templateId = 'template_fco071p';

      // Template parameters that match your EmailJS template
      const templateParams = {
        from_name: formData.name,
        from_email: formData.email,
        to_name: 'Siva',
        to_email: 'sivalisivali143@gmail.com',
        message: formData.message,
        reply_to: formData.email
      };

      console.log('Sending email with params:', templateParams);

      // Send email via EmailJS
      const result = await emailjs.send(serviceId, templateId, templateParams);
      
      console.log('EmailJS result:', result);

      if (result.status === 200) {
        toast({
          title: "Message Sent Successfully!",
          description: "Thank you for reaching out. I'll get back to you soon!",
        });

        // Reset form
        setFormData({ name: "", email: "", message: "" });
      } else {
        throw new Error('Failed to send email');
      }
    } catch (error) {
      console.error('EmailJS Error:', error);
      toast({
        title: "Failed to Send Message",
        description: "There was an issue sending your message. Please try again or contact me directly.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleLinkClick = (link: string, title: string) => {
    console.log(`Attempting to open ${title}:`, link);
    try {
      window.open(link, '_blank', 'noopener,noreferrer');
    } catch (error) {
      console.error(`Failed to open ${title}:`, error);
      toast({
        title: "Link Error",
        description: `Unable to open ${title}. Please try copying the link manually.`,
        variant: "destructive"
      });
    }
  };

  const contactInfo = [
    {
      icon: Mail,
      title: "Email",
      value: "pallasiva85636@gmail.com",
      link: "mailto:pallasiva85636@gmail.com"
    },
    {
      icon: Phone,
      title: "Phone",
      value: "+91 6300090126",
      link: "tel:+916300090126"
    },
    {
      icon: LinkedinIcon,
      title: "LinkedIn",
      value: "Connect with me",
      link: "https://www.linkedin.com/in/pallasiva"
    },
    {
      icon: Github,
      title: "GitHub",
      value: "View my projects",
      link: "https://github.com/sivapalla2003"
    }
  ];

  return (
    <div className="py-20 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">Get In Touch</h2>
          <p className="text-xl text-slate-300">
            Let's discuss opportunities and collaborations
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card className="bg-white/10 backdrop-blur-sm border-slate-700">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-white mb-6">Send a Message</h3>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Input
                    type="text"
                    name="name"
                    placeholder="Your Name"
                    value={formData.name}
                    onChange={handleInputChange}
                    disabled={isLoading}
                    className="bg-white/10 border-slate-600 text-white placeholder-slate-400"
                    required
                  />
                </div>
                
                <div>
                  <Input
                    type="email"
                    name="email"
                    placeholder="Your Email"
                    value={formData.email}
                    onChange={handleInputChange}
                    disabled={isLoading}
                    className="bg-white/10 border-slate-600 text-white placeholder-slate-400"
                    required
                  />
                </div>
                
                <div>
                  <Textarea
                    name="message"
                    placeholder="Your Message"
                    rows={6}
                    value={formData.message}
                    onChange={handleInputChange}
                    disabled={isLoading}
                    className="bg-white/10 border-slate-600 text-white placeholder-slate-400 resize-none"
                    required
                  />
                </div>
                
                <Button 
                  type="submit" 
                  size="lg" 
                  disabled={isLoading}
                  className="w-full bg-teal-600 hover:bg-teal-700 text-white disabled:opacity-50"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Sending Message...
                    </>
                  ) : (
                    <>
                      <Send className="mr-2 h-4 w-4" />
                      Send Message
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-white mb-6">Contact Information</h3>
              <p className="text-slate-300 leading-relaxed mb-8">
                I'm always open to discussing new opportunities, interesting projects, 
                or potential collaborations in AI and data science. Feel free to reach out!
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {contactInfo.map((info, index) => {
                const IconComponent = info.icon;
                const isEmailOrPhone = info.title === "Email" || info.title === "Phone";
                
                return (
                  <div
                    key={index}
                    onClick={() => {
                      if (isEmailOrPhone) {
                        window.location.href = info.link;
                      } else {
                        handleLinkClick(info.link, info.title);
                      }
                    }}
                    className="block p-6 bg-white/10 backdrop-blur-sm rounded-lg border border-slate-700 hover:bg-white/15 transition-all duration-300 group cursor-pointer"
                  >
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-teal-600 rounded-full group-hover:bg-teal-500 transition-colors">
                        <IconComponent size={20} className="text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">{info.title}</h4>
                        <p className="text-slate-300 text-sm">{info.value}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Location */}
            <Card className="bg-white/10 backdrop-blur-sm border-slate-700">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-purple-600 rounded-full">
                    <MapPin size={20} className="text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white">Location</h4>
                    <p className="text-slate-300">India</p>
                    <p className="text-slate-400 text-sm">Available for remote work globally</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
