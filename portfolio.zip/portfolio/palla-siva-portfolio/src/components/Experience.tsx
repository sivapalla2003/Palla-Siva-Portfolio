import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Briefcase, CheckCircle, Calendar, Building, Sparkles } from "lucide-react";

const Experience = () => {
  const experiences = [
    {
      title: "AI Prompt Engineer Intern",
      company: "Smart Intern",
      duration: "Feb 2025 - May 2025",
      highlights: [
        "Built NLP-based tools for content generation",
        "Developed comprehensive prompt documentation",
        "Integrated AI models with web applications",
        "Improved prompt efficiency by 40%"
      ],
      skills: ["Prompt Engineering", "NLP", "OpenAI API", "Documentation"],
      color: "from-teal-500 to-teal-600",
      bgColor: "bg-teal-50",
      current: false
    },
    {
      title: "AI Intern",
      company: "Microsoft/SAP AICTE TechSaksham",
      duration: "Dec 2024 - Jan 2025",
      highlights: [
        "Participated in advanced AI training programs",
        "Worked on machine learning projects",
        "Collaborated with industry professionals",
        "Gained hands-on experience with cloud AI services"
      ],
      skills: ["Machine Learning", "Cloud AI", "Microsoft Azure", "SAP"],
      color: "from-blue-500 to-blue-600",
      bgColor: "bg-blue-50",
      current: false
    },
    {
      title: "AI & ML Intern",
      company: "APSSDC / Edunet",
      duration: "May 2024 - June 2024",
      highlights: [
        "Developed spam detection systems",
        "Built sentiment analysis models",
        "Achieved 90%+ accuracy in classification tasks",
        "Implemented end-to-end ML pipelines"
      ],
      skills: ["Python", "Scikit-Learn", "LSTM", "SVM", "Random Forest"],
      color: "from-purple-500 to-purple-600",
      bgColor: "bg-purple-50",
      current: false
    }
  ];

  return (
    <div className="py-20 bg-gradient-to-br from-slate-50 via-white to-slate-100 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 right-10 w-80 h-80 bg-gradient-to-r from-teal-400/10 to-blue-400/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 left-10 w-96 h-96 bg-gradient-to-r from-purple-400/10 to-pink-400/10 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm border border-slate-200/50 rounded-full text-slate-600 text-sm font-medium mb-6">
            <Briefcase className="w-4 h-4" />
            Professional Journey
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
            Work <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-600 to-blue-600">Experience</span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Building expertise through hands-on experience in AI and technology
          </p>
        </div>

        <div className="space-y-8 max-w-6xl mx-auto">
          {experiences.map((exp, index) => (
            <Card key={index} className="hover:shadow-2xl transition-all duration-500 border-0 bg-white/80 backdrop-blur-sm shadow-xl group hover:scale-[1.02]">
              <CardContent className="p-8 lg:p-10">
                <div className="grid lg:grid-cols-12 gap-8">
                  {/* Left: Company info with icon */}
                  <div className="lg:col-span-4">
                    <div className="flex items-start gap-4 mb-6">
                      <div className={`p-3 rounded-2xl bg-gradient-to-r ${exp.color} shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                        <Building className="h-6 w-6 text-white" />
                      </div>
                      <div className="flex-1">
                        {exp.current && (
                          <Badge className="bg-green-100 text-green-700 border-green-200 mb-3">
                            <Sparkles className="w-3 h-3 mr-1" />
                            Current
                          </Badge>
                        )}
                        <h3 className="text-xl lg:text-2xl font-bold text-slate-900 mb-2 leading-tight">
                          {exp.title}
                        </h3>
                        <p className="text-teal-600 font-bold text-lg mb-3">
                          {exp.company}
                        </p>
                        <div className="flex items-center gap-2 text-slate-500">
                          <Calendar className="h-4 w-4" />
                          <span className="font-medium">{exp.duration}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Middle: Achievements */}
                  <div className="lg:col-span-5">
                    <h4 className="font-bold text-slate-800 mb-4 text-lg flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 text-teal-600" />
                      Key Achievements
                    </h4>
                    <ul className="space-y-3">
                      {exp.highlights.map((highlight, idx) => (
                        <li key={idx} className="text-slate-600 flex items-start gap-3 group-hover:translate-x-1 transition-transform duration-300" style={{ transitionDelay: `${idx * 100}ms` }}>
                          <div className="w-2 h-2 bg-gradient-to-r from-teal-500 to-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                          <span className="leading-relaxed">{highlight}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Right: Skills */}
                  <div className="lg:col-span-3">
                    <h4 className="font-bold text-slate-800 mb-4 text-lg">Technologies</h4>
                    <div className="flex flex-wrap gap-2">
                      {exp.skills.map((skill, idx) => (
                        <Badge 
                          key={idx} 
                          variant="outline" 
                          className={`${exp.bgColor} border-slate-200 hover:scale-105 transition-all duration-200 cursor-default`}
                          style={{ animationDelay: `${idx * 100}ms` }}
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Experience summary */}
        <div className="mt-20 grid grid-cols-1 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
          <div className="text-center p-6 bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg border border-slate-200/50">
            <div className="text-3xl font-bold text-teal-600 mb-2">3+</div>
            <div className="text-slate-600 font-medium">Internships</div>
          </div>
          <div className="text-center p-6 bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg border border-slate-200/50">
            <div className="text-3xl font-bold text-blue-600 mb-2">12+</div>
            <div className="text-slate-600 font-medium">Months Experience</div>
          </div>
          <div className="text-center p-6 bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg border border-slate-200/50">
            <div className="text-3xl font-bold text-purple-600 mb-2">40%</div>
            <div className="text-slate-600 font-medium">Efficiency Improvement</div>
          </div>
          <div className="text-center p-6 bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg border border-slate-200/50">
            <div className="text-3xl font-bold text-green-600 mb-2">90%+</div>
            <div className="text-slate-600 font-medium">Project Accuracy</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Experience;
