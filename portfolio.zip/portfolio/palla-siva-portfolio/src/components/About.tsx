
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Target, Lightbulb, Code, Sparkles, ArrowRight } from "lucide-react";
import { downloadResume } from "@/utils/resumeGenerator";

const About = () => {
  const handleDownloadResume = () => {
    downloadResume();
  };

  return (
    <div className="py-20 bg-gradient-to-br from-slate-50 via-white to-slate-100 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 right-20 w-64 h-64 bg-teal-400/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 left-20 w-80 h-80 bg-blue-400/5 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm border border-teal-200/50 rounded-full text-teal-600 text-sm font-medium mb-6 animate-fade-in">
            <Sparkles className="w-4 h-4" />
            Get to know me
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6 animate-fade-in delay-200">
            About <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-600 to-blue-600">Me</span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto animate-fade-in delay-300">
            Designing Solutions, Not Just Visuals
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <div className="space-y-8 animate-fade-in delay-500">
            <div className="prose prose-lg max-w-none">
              <div className="space-y-6 text-slate-700 leading-relaxed">
                <p className="text-lg">
                  I'm a recent graduate in <span className="font-semibold text-slate-900 bg-gradient-to-r from-teal-100 to-blue-100 px-2 py-1 rounded">Artificial Intelligence & Data Science</span> with a 
                  deep passion for innovation and problem-solving. My journey in tech has been driven by 
                  curiosity and a desire to create meaningful solutions using cutting-edge AI technologies.
                </p>
                
                <p className="text-lg">
                  My expertise spans across <span className="font-semibold text-teal-700">Prompt Engineering</span>, <span className="font-semibold text-blue-700">Generative AI</span>,
                  <span className="font-semibold text-purple-700"> Python Programming</span>, and <span className="font-semibold text-green-700">Data Analytics</span>. I believe in 
                  combining creativity with analytical thinking to solve real-world problems and create 
                  impactful digital experiences.
                </p>
                
                <p className="text-lg">
                  When I'm not coding or exploring the latest AI trends, you'll find me contributing to 
                  open-source projects, participating in hackathons, or sharing knowledge with the 
                  developer community.
                </p>
              </div>
            </div>

            <Button 
              onClick={handleDownloadResume}
              size="lg"
              className="bg-gradient-to-r from-teal-600 to-teal-700 hover:from-teal-700 hover:to-teal-800 text-white px-8 py-4 text-lg font-semibold shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300 group"
            >
              <Download className="mr-2 h-5 w-5 group-hover:animate-bounce" />
              Download Resume
              <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>

          {/* Right Content - Feature Cards */}
          <div className="grid grid-cols-1 gap-6 animate-fade-in delay-700">
            <Card className="border-0 bg-white/70 backdrop-blur-sm shadow-xl hover:shadow-2xl transition-all duration-500 border-l-4 border-l-teal-500 group hover:scale-105">
              <CardContent className="p-8">
                <div className="flex items-start gap-6">
                  <div className="bg-gradient-to-br from-teal-500 to-teal-600 p-4 rounded-2xl shadow-lg group-hover:scale-110 transition-transform duration-300">
                    <Target className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-slate-900 mb-3 text-lg">Problem Solver</h3>
                    <p className="text-slate-600 leading-relaxed">
                      Passionate about identifying challenges and developing innovative AI-driven solutions 
                      that make a real difference in people's lives.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 bg-white/70 backdrop-blur-sm shadow-xl hover:shadow-2xl transition-all duration-500 border-l-4 border-l-blue-500 group hover:scale-105">
              <CardContent className="p-8">
                <div className="flex items-start gap-6">
                  <div className="bg-gradient-to-br from-blue-500 to-blue-600 p-4 rounded-2xl shadow-lg group-hover:scale-110 transition-transform duration-300">
                    <Lightbulb className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-slate-900 mb-3 text-lg">Innovation Driven</h3>
                    <p className="text-slate-600 leading-relaxed">
                      Always exploring the latest in AI and machine learning to stay ahead of the curve 
                      and implement cutting-edge solutions.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 bg-white/70 backdrop-blur-sm shadow-xl hover:shadow-2xl transition-all duration-500 border-l-4 border-l-purple-500 group hover:scale-105">
              <CardContent className="p-8">
                <div className="flex items-start gap-6">
                  <div className="bg-gradient-to-br from-purple-500 to-purple-600 p-4 rounded-2xl shadow-lg group-hover:scale-110 transition-transform duration-300">
                    <Code className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-slate-900 mb-3 text-lg">Technical Excellence</h3>
                    <p className="text-slate-600 leading-relaxed">
                      Committed to writing clean, efficient code and following best practices in 
                      software development and AI implementation.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
