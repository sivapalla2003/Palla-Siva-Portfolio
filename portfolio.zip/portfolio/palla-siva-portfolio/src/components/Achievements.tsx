
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Award, Star, Target } from "lucide-react";

const Achievements = () => {
  const achievements = [
    {
      title: "Prompthon Winner",
      organization: "Andala AI",
      description: "Won first place in the Prompthon competition organized by Andala AI, demonstrating excellence in prompt engineering and creative AI solutions.",
      award: "Cash Prize",
      year: "2024",
      icon: Trophy,
      color: "text-yellow-600 bg-yellow-100"
    },
    {
      title: "SWAIT.AI Learnathon Participant",
      organization: "GUVI",
      description: "Successfully participated in GUVI's SWAIT.AI Learnathon, showcasing skills in AI and machine learning through hands-on projects.",
      award: "Certificate",
      year: "2024",
      icon: Award,
      color: "text-blue-600 bg-blue-100"
    },
    {
      title: "Research Publication",
      organization: "IJIRSET",
      description: "Published research paper on 'Software Behaviour Prediction Utilizing Multi-Label Classification and LSTM Networks' in a peer-reviewed journal.",
      award: "Publication",
      year: "2025",
      icon: Star,
      color: "text-teal-600 bg-teal-100"
    },
    {
      title: "Academic Excellence",
      organization: "SITAM",
      description: "Maintained consistent academic performance with a GPA of 7.65 in BTech AI & Data Science program.",
      award: "Academic Achievement",
      year: "2025",
      icon: Target,
      color: "text-purple-600 bg-purple-100"
    }
  ];

  return (
    <div className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">Achievements</h2>
          <p className="text-xl text-slate-600">Recognition and milestones in my journey</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {achievements.map((achievement, index) => {
            const IconComponent = achievement.icon;
            return (
              <Card key={index} className="hover:shadow-xl transition-all duration-300 border-l-4 border-l-teal-500">
                <CardContent className="p-8">
                  <div className="flex items-start gap-6">
                    {/* Icon */}
                    <div className={`p-4 rounded-full ${achievement.color} flex-shrink-0`}>
                      <IconComponent size={24} />
                    </div>

                    {/* Content */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="text-xl font-bold text-slate-900 mb-1">
                            {achievement.title}
                          </h3>
                          <p className="text-teal-600 font-semibold">
                            {achievement.organization}
                          </p>
                        </div>
                        <div className="text-right">
                          <Badge variant="secondary" className="bg-slate-100 text-slate-700">
                            {achievement.year}
                          </Badge>
                        </div>
                      </div>

                      <p className="text-slate-600 leading-relaxed mb-4">
                        {achievement.description}
                      </p>

                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="border-teal-200 text-teal-700">
                          {achievement.award}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Achievement Stats */}
        <div className="mt-16 bg-white rounded-2xl p-8 shadow-lg">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="space-y-2">
              <div className="text-3xl font-bold text-teal-600">4+</div>
              <div className="text-slate-600 font-medium">Major Achievements</div>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-bold text-blue-600">1</div>
              <div className="text-slate-600 font-medium">Competition Win</div>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-bold text-purple-600">1</div>
              <div className="text-slate-600 font-medium">Research Publication</div>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-bold text-green-600">7.65</div>
              <div className="text-slate-600 font-medium">Academic GPA</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Achievements;
