

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Download, Calendar, BookOpen } from "lucide-react";

const Research = () => {
  const publications = [
    {
      title: "Software Behaviour Prediction Utilizing Multi-Label Classification and LSTM Networks",
      journal: "International Journal of Innovative Research in Science, Engineering and Technology (IJIRSET)",
      volume: "Volume 14, Issue 4",
      publishedDate: "April 2025",
      abstract: "This research presents a novel approach to predicting software behavior using multi-label classification techniques combined with Long Short-Term Memory (LSTM) networks. The study demonstrates improved accuracy in identifying potential software issues before they manifest in production environments.",
      keywords: ["Machine Learning", "LSTM", "Software Engineering", "Predictive Analytics", "Multi-label Classification"],
      status: "Published",
      doi: "10.15680/IJIRSET.2025.1404000",
      featured: true,
      certificateUrl: "/lovable-uploads/7f48ee78-deaf-4ec3-93fd-05be084df36a.png"
    }
  ];

  const researchInterests = [
    "Artificial Intelligence & Machine Learning",
    "Natural Language Processing",
    "Prompt Engineering & Generative AI",
    "Software Behavior Prediction",
    "Deep Learning Applications",
    "Data Science & Analytics"
  ];

  const handleDownloadPDF = (certificateUrl: string) => {
    window.open(certificateUrl, '_blank');
  };

  const handleViewPublication = (certificateUrl: string) => {
    window.open(certificateUrl, '_blank');
  };

  return (
    <div className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">Research & Publications</h2>
          <p className="text-xl text-slate-600">Contributing to the advancement of AI and machine learning</p>
        </div>

        {/* Featured Publication */}
        {publications.map((publication, index) => (
          <Card key={index} className="mb-12 hover:shadow-xl transition-all duration-300 border-t-4 border-t-teal-500">
            <CardContent className="p-8">
              <div className="space-y-6">
                {/* Header */}
                <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <Badge 
                        variant="secondary" 
                        className="bg-green-100 text-green-700 border-green-200"
                      >
                        {publication.status}
                      </Badge>
                      <Badge variant="outline" className="border-teal-200 text-teal-700">
                        Featured
                      </Badge>
                    </div>
                    
                    <h3 className="text-2xl font-bold text-slate-900 mb-3 leading-tight">
                      {publication.title}
                    </h3>
                    
                    <div className="space-y-2 text-slate-600">
                      <p className="font-semibold">{publication.journal}</p>
                      <div className="flex items-center gap-4 text-sm">
                        <span className="flex items-center gap-1">
                          <Calendar size={16} />
                          {publication.publishedDate}
                        </span>
                        <span className="flex items-center gap-1">
                          <BookOpen size={16} />
                          {publication.volume}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-3">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex items-center gap-2"
                      onClick={() => handleDownloadPDF(publication.certificateUrl)}
                    >
                      <Download size={16} />
                      Download PDF
                    </Button>
                    <Button 
                      size="sm" 
                      className="bg-teal-600 hover:bg-teal-700 flex items-center gap-2"
                      onClick={() => handleViewPublication(publication.certificateUrl)}
                    >
                      <ExternalLink size={16} />
                      View Publication
                    </Button>
                  </div>
                </div>

                {/* Abstract */}
                <div>
                  <h4 className="font-semibold text-slate-800 mb-3">Abstract</h4>
                  <p className="text-slate-600 leading-relaxed">
                    {publication.abstract}
                  </p>
                </div>

                {/* Keywords */}
                <div>
                  <h4 className="font-semibold text-slate-800 mb-3">Keywords</h4>
                  <div className="flex flex-wrap gap-2">
                    {publication.keywords.map((keyword, idx) => (
                      <Badge key={idx} variant="secondary" className="bg-slate-100 text-slate-700">
                        {keyword}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* DOI */}
                <div className="pt-4 border-t border-slate-100">
                  <p className="text-sm text-slate-500">
                    DOI: <span className="font-mono text-teal-600">{publication.doi}</span>
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {/* Research Interests */}
        <div className="grid lg:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-bold text-slate-900 mb-6">Research Interests</h3>
            <div className="space-y-4">
              {researchInterests.map((interest, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-teal-500 rounded-full"></div>
                  <span className="text-slate-700 font-medium">{interest}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-2xl font-bold text-slate-900 mb-6">Research Impact</h3>
            <div className="grid grid-cols-2 gap-6">
              <div className="text-center p-6 bg-slate-50 rounded-lg">
                <div className="text-3xl font-bold text-teal-600 mb-2">1</div>
                <div className="text-slate-600 font-medium">Publications</div>
              </div>
              <div className="text-center p-6 bg-slate-50 rounded-lg">
                <div className="text-3xl font-bold text-blue-600 mb-2">2025</div>
                <div className="text-slate-600 font-medium">Latest Year</div>
              </div>
              <div className="text-center p-6 bg-slate-50 rounded-lg">
                <div className="text-3xl font-bold text-purple-600 mb-2">IJIRSET</div>
                <div className="text-slate-600 font-medium text-sm">Journal</div>
              </div>
              <div className="text-center p-6 bg-slate-50 rounded-lg">
                <div className="text-3xl font-bold text-green-600 mb-2">AI/ML</div>
                <div className="text-slate-600 font-medium text-sm">Focus Area</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Research;

