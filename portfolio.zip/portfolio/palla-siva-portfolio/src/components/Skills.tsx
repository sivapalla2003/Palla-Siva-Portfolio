
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const Skills = () => {
  const skillCategories = [
    {
      category: "Programming Languages",
      skills: ["Python", "SQL", "JavaScript", "HTML/CSS"],
      color: "bg-blue-100 text-blue-700 border-blue-200"
    },
    {
      category: "AI & Machine Learning",
      skills: ["LSTM", "SVM", "Random Forest", "Naive Bayes", "Deep Learning", "NLP"],
      color: "bg-teal-100 text-teal-700 border-teal-200"
    },
    {
      category: "Data Analysis & Visualization",
      skills: ["Power BI", "Pandas", "NumPy", "Scikit-Learn", "Data Storytelling"],
      color: "bg-purple-100 text-purple-700 border-purple-200"
    },
    {
      category: "Generative AI",
      skills: ["ChatGPT", "DALL·E", "OpenAI API", "Hugging Face", "Prompt Engineering"],
      color: "bg-green-100 text-green-700 border-green-200"
    },
    {
      category: "DevOps & Cloud",
      skills: ["Docker", "GitHub", "AWS", "Google Colab", "Version Control"],
      color: "bg-orange-100 text-orange-700 border-orange-200"
    },
    {
      category: "Soft Skills",
      skills: ["Communication", "Teamwork", "Leadership", "Problem Solving", "Critical Thinking"],
      color: "bg-pink-100 text-pink-700 border-pink-200"
    }
  ];

  return (
    <div className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">Skills & Expertise</h2>
          <p className="text-xl text-slate-600">Technologies and tools I work with</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-slate-900 mb-4 text-center">
                  {category.category}
                </h3>
                
                <div className="flex flex-wrap gap-2 justify-center">
                  {category.skills.map((skill, skillIndex) => (
                    <Badge 
                      key={skillIndex} 
                      variant="outline"
                      className={`${category.color} hover:scale-105 transition-transform duration-200 cursor-default`}
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Skill Level Indicators */}
        <div className="mt-16 grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { skill: "Python", level: 90 },
            { skill: "Machine Learning", level: 85 },
            { skill: "Prompt Engineering", level: 95 },
            { skill: "Data Analysis", level: 80 }
          ].map((item, index) => (
            <div key={index} className="text-center">
              <div className="relative w-24 h-24 mx-auto mb-4">
                <svg className="w-24 h-24 transform -rotate-90" viewBox="0 0 36 36">
                  <path
                    className="text-slate-300"
                    d="M18 2.0845
                      a 15.9155 15.9155 0 0 1 0 31.831
                      a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                  />
                  <path
                    className="text-teal-600"
                    d="M18 2.0845
                      a 15.9155 15.9155 0 0 1 0 31.831
                      a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeDasharray={`${item.level}, 100`}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-xl font-bold text-slate-900">{item.level}%</span>
                </div>
              </div>
              <p className="font-semibold text-slate-800">{item.skill}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Skills;
