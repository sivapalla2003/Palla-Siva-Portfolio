
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const Certifications = () => {
  const certifications = [
    {
      title: "Generative AI Fundamentals",
      issuer: "BCG X",
      year: "2024",
      category: "AI/ML",
      color: "bg-blue-100 text-blue-700"
    },
    {
      title: "Azure AI Fundamentals",
      issuer: "Microsoft",
      year: "2024",
      category: "Cloud AI",
      color: "bg-teal-100 text-teal-700"
    },
    {
      title: "Python Programming",
      issuer: "NPTEL",
      year: "2024",
      category: "Programming",
      color: "bg-green-100 text-green-700"
    },
    {
      title: "Prompt Engineering",
      issuer: "Infosys",
      year: "2024",
      category: "AI/ML",
      color: "bg-purple-100 text-purple-700"
    },
    {
      title: "Machine Learning Basics",
      issuer: "LinkedIn Learning",
      year: "2023",
      category: "AI/ML",
      color: "bg-orange-100 text-orange-700"
    },
    {
      title: "AWS Cloud Practitioner",
      issuer: "Amazon Web Services",
      year: "2024",
      category: "Cloud",
      color: "bg-yellow-100 text-yellow-700"
    },
    {
      title: "Data Science with Python",
      issuer: "IBM",
      year: "2023",
      category: "Data Science",
      color: "bg-pink-100 text-pink-700"
    },
    {
      title: "Deep Learning Specialization",
      issuer: "TCS iON",
      year: "2024",
      category: "AI/ML",
      color: "bg-indigo-100 text-indigo-700"
    },
    {
      title: "Computer Programming",
      issuer: "NIELIT",
      year: "2023",
      category: "Programming",
      color: "bg-red-100 text-red-700"
    }
  ];

  const categories = ["All", "AI/ML", "Programming", "Cloud", "Data Science"];

  return (
    <div className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">Certifications</h2>
          <p className="text-xl text-slate-600">Professional credentials and achievements</p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <Badge 
              key={category}
              variant="outline" 
              className="px-4 py-2 cursor-pointer hover:bg-teal-100 hover:text-teal-700 transition-colors"
            >
              {category}
            </Badge>
          ))}
        </div>

        {/* Certifications Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {certifications.map((cert, index) => (
            <Card key={index} className="hover:shadow-lg transition-all duration-300 group">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <Badge 
                    variant="secondary" 
                    className={`${cert.color} text-xs`}
                  >
                    {cert.category}
                  </Badge>
                  <span className="text-sm text-slate-500 font-medium">{cert.year}</span>
                </div>
                
                <h3 className="text-lg font-bold text-slate-900 mb-2 group-hover:text-teal-600 transition-colors">
                  {cert.title}
                </h3>
                
                <p className="text-slate-600 font-medium text-sm">
                  {cert.issuer}
                </p>
                
                <div className="mt-4 pt-4 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-500">Certified</span>
                    <div className="w-8 h-8 bg-teal-100 rounded-full flex items-center justify-center">
                      <span className="text-teal-600 text-xs font-bold">✓</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Stats Section */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div>
            <div className="text-3xl font-bold text-teal-600 mb-2">9+</div>
            <div className="text-slate-600">Certifications</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-blue-600 mb-2">5</div>
            <div className="text-slate-600">AI/ML Certs</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-purple-600 mb-2">3</div>
            <div className="text-slate-600">Cloud Platforms</div>
          </div>
          <div>
            <div className="text-3xl font-bold text-green-600 mb-2">2024</div>
            <div className="text-slate-600">Latest Year</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Certifications;
