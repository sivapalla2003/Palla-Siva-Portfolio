
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GraduationCap, Calendar, Award } from "lucide-react";

const Education = () => {
  const education = [
    {
      degree: "BTech in CSE (AI & DS)",
      institution: "Satya Institute of Technology & Management",
      duration: "2021 - 2025",
      gpa: "7.65",
      color: "from-teal-500 to-teal-600",
      bgColor: "bg-teal-50",
      textColor: "text-teal-700",
      borderColor: "border-teal-200"
    },
    {
      degree: "Intermediate (MPC)",
      institution: "Sri Balaji Jr. College",
      duration: "2018 - 2020",
      gpa: "9.46",
      color: "from-blue-500 to-blue-600",
      bgColor: "bg-blue-50",
      textColor: "text-blue-700",
      borderColor: "border-blue-200"
    },
    {
      degree: "SSC",
      institution: "Z.P. High School",
      duration: "2013 - 2018",
      gpa: "9.2",
      color: "from-purple-500 to-purple-600",
      bgColor: "bg-purple-50",
      textColor: "text-purple-700",
      borderColor: "border-purple-200"
    }
  ];

  return (
    <div className="py-20 bg-white relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-10 left-10 w-72 h-72 bg-gradient-to-r from-teal-400/10 to-blue-400/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-gradient-to-r from-purple-400/10 to-pink-400/10 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-slate-100/80 backdrop-blur-sm border border-slate-200/50 rounded-full text-slate-600 text-sm font-medium mb-6">
            <GraduationCap className="w-4 h-4" />
            Academic Journey
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
            My <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-600 to-blue-600">Education</span>
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Building a strong foundation in technology and science
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          {/* Modern Timeline line */}
          <div className="absolute left-8 top-0 bottom-0 w-1 bg-gradient-to-b from-teal-500 via-blue-500 to-purple-500 rounded-full hidden md:block opacity-30"></div>
          <div className="absolute left-8 top-0 bottom-0 w-1 bg-gradient-to-b from-teal-500 via-blue-500 to-purple-500 rounded-full hidden md:block animate-pulse"></div>

          <div className="space-y-12">
            {education.map((edu, index) => (
              <div key={index} className="relative group">
                {/* Timeline dot */}
                <div className={`absolute left-6 w-6 h-6 bg-gradient-to-r ${edu.color} rounded-full border-4 border-white shadow-lg hidden md:block group-hover:scale-125 transition-transform duration-300`}></div>
                
                <Card className={`md:ml-20 hover:shadow-2xl transition-all duration-500 border-0 bg-white/80 backdrop-blur-sm shadow-xl group-hover:scale-105 ${edu.borderColor} border-l-4`}>
                  <CardContent className="p-8">
                    <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-4">
                          <div className={`p-2 rounded-lg bg-gradient-to-r ${edu.color}`}>
                            <GraduationCap className="h-5 w-5 text-white" />
                          </div>
                          <Badge variant="outline" className={`${edu.bgColor} ${edu.textColor} ${edu.borderColor} px-3 py-1`}>
                            Completed
                          </Badge>
                        </div>
                        
                        <h3 className="text-2xl font-bold text-slate-900 mb-3">
                          {edu.degree}
                        </h3>
                        <p className="text-slate-600 font-semibold text-lg mb-3">
                          {edu.institution}
                        </p>
                        <div className="flex items-center gap-2 text-slate-500">
                          <Calendar className="h-4 w-4" />
                          <span className="font-medium">{edu.duration}</span>
                        </div>
                      </div>
                      
                      <div className="flex flex-col items-start lg:items-end gap-3">
                        <div className={`bg-gradient-to-r ${edu.color} rounded-2xl p-6 text-white shadow-lg group-hover:shadow-xl transition-shadow`}>
                          <div className="flex items-center gap-2 mb-2">
                            <Award className="h-5 w-5" />
                            <span className="text-sm font-medium opacity-90">GPA</span>
                          </div>
                          <div className="text-3xl font-bold">{edu.gpa}</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>

        {/* Stats section */}
        <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <div className="text-center p-6 bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg border border-slate-200/50">
            <div className="text-4xl font-bold text-teal-600 mb-2">4</div>
            <div className="text-slate-600 font-medium">Years of Study</div>
          </div>
          <div className="text-center p-6 bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg border border-slate-200/50">
            <div className="text-4xl font-bold text-blue-600 mb-2">8.77</div>
            <div className="text-slate-600 font-medium">Average GPA</div>
          </div>
          <div className="text-center p-6 bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg border border-slate-200/50">
            <div className="text-4xl font-bold text-purple-600 mb-2">2025</div>
            <div className="text-slate-600 font-medium">Graduation Year</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Education;
