
import jsPDF from 'jspdf';

export const downloadPortfolioCV = () => {
  const pdf = new jsPDF();
  const pageWidth = pdf.internal.pageSize.width;
  const pageHeight = pdf.internal.pageSize.height;
  const margin = 20;
  const lineHeight = 6;
  let yPosition = 30;

  // Define colors
  const primaryBlue = '#2563eb';
  const lightBlue = '#dbeafe';
  const darkGray = '#374151';
  const lightGray = '#6b7280';
  const tealColor = '#14b8a6';

  // Helper function to check if we need a new page
  const checkNewPage = (requiredSpace = 20) => {
    if (yPosition + requiredSpace > pageHeight - margin) {
      pdf.addPage();
      yPosition = 30;
    }
  };

  // Helper function to add section
  const addSection = (title: string, content: string[], isHeader = false) => {
    checkNewPage(50);
    
    if (!isHeader) {
      pdf.setFillColor(primaryBlue);
      pdf.rect(margin, yPosition - 3, pageWidth - 2 * margin, 8, 'F');
      pdf.setTextColor(255, 255, 255);
      pdf.setFontSize(12);
      pdf.setFont('helvetica', 'bold');
      pdf.text(title, margin + 2, yPosition + 2);
      yPosition += 12;
    }

    pdf.setTextColor(darkGray);
    content.forEach((line) => {
      checkNewPage();
      if (line.startsWith('•')) {
        pdf.setFont('helvetica', 'normal');
        pdf.setFontSize(10);
        pdf.text(line, margin + 5, yPosition);
      } else if (line.includes('|') || line.includes('–')) {
        pdf.setFont('helvetica', 'bold');
        pdf.setFontSize(11);
        pdf.text(line, margin, yPosition);
      } else if (line === '') {
        yPosition += 3;
        return;
      } else {
        pdf.setFont('helvetica', 'normal');
        pdf.setFontSize(10);
        pdf.text(line, margin, yPosition);
      }
      yPosition += lineHeight;
    });
    yPosition += 5;
  };

  // Header Section
  pdf.setFillColor(lightBlue);
  pdf.rect(0, 0, pageWidth, 60, 'F');
  
  pdf.setTextColor(primaryBlue);
  pdf.setFontSize(24);
  pdf.setFont('helvetica', 'bold');
  pdf.text('PALLA SIVA', margin, 25);
  
  pdf.setTextColor(darkGray);
  pdf.setFontSize(14);
  pdf.setFont('helvetica', 'normal');
  pdf.text('AI Enthusiast | Prompt Engineer | Generative AI Explorer', margin, 35);
  
  pdf.setFontSize(10);
  pdf.text('Email: pallasiva85636@gmail.com', margin, 45);
  pdf.text('LinkedIn: linkedin.com/in/palla-siva | GitHub: github.com/palla-siva', margin, 52);

  yPosition = 75;

  // Professional Summary
  addSection('PROFESSIONAL SUMMARY', [
    'BTech student in Computer Science Engineering (AI & Data Science) with expertise in artificial',
    'intelligence, machine learning, and prompt engineering. Passionate about generative AI and Python',
    'programming with hands-on experience through multiple internships. Strong problem-solving abilities',
    'with a focus on creating innovative AI-driven solutions and building the future one algorithm at a time.'
  ]);

  // Education
  addSection('EDUCATION', [
    'Bachelor of Technology in Computer Science Engineering (AI & Data Science)',
    'Satya Institute of Technology & Management | 2021 - 2025 | CGPA: 7.65',
    '',
    'Intermediate (MPC)',
    'Sri Balaji Jr. College | 2018 - 2020 | CGPA: 9.46',
    '',
    'Secondary School Certificate',
    'Z.P. High School | 2013 - 2018 | CGPA: 9.2'
  ]);

  // Work Experience
  addSection('PROFESSIONAL EXPERIENCE', [
    'AI Prompt Engineer Intern | Smart Intern | February 2025 - May 2025',
    '• Developed advanced prompt engineering techniques for content generation and AI optimization',
    '• Built comprehensive prompt documentation improving team efficiency by 40%',
    '• Integrated AI models with web applications using OpenAI API and modern frameworks',
    '• Collaborated with cross-functional teams to optimize AI model performance and accuracy',
    '',
    'AI Intern | Microsoft/SAP AICTE TechSaksham | December 2024 - January 2025',
    '• Participated in advanced AI training programs led by industry professionals',
    '• Worked on machine learning projects using Microsoft Azure and SAP technologies',
    '• Gained hands-on experience with cloud AI services and enterprise solutions',
    '• Developed technical skills in cloud computing and AI implementation strategies',
    '',
    'AI & ML Intern | APSSDC / Edunet Foundation | May 2024 - June 2024',
    '• Developed spam detection systems achieving 92% accuracy using machine learning algorithms',
    '• Built sentiment analysis models using LSTM, SVM, and Random Forest techniques',
    '• Implemented end-to-end ML pipelines with Python, Scikit-Learn, and TensorFlow',
    '• Analyzed large datasets and created comprehensive data visualization dashboards'
  ]);

  // Technical Skills
  addSection('TECHNICAL SKILLS', [
    'Programming Languages:',
    '• Python, JavaScript, TypeScript, SQL, HTML5, CSS3',
    '',
    'AI/ML Technologies:',
    '• TensorFlow, PyTorch, Scikit-Learn, OpenAI API, Hugging Face Transformers',
    '• Natural Language Processing, Computer Vision, Deep Learning',
    '',
    'Web Technologies:',
    '• React.js, Node.js, Express.js, Tailwind CSS, Bootstrap',
    '',
    'Databases & Cloud:',
    '• MongoDB, PostgreSQL, MySQL, Microsoft Azure, AWS',
    '',
    'Tools & Technologies:',
    '• Git, Docker, Jupyter Notebooks, VS Code, Postman',
    '',
    'Specializations:',
    '• Prompt Engineering, Generative AI, Data Analytics, Machine Learning'
  ]);

  // Projects
  addSection('KEY PROJECTS', [
    'Advanced SMS Spam Detection System',
    '• Developed machine learning model achieving 92% accuracy in spam classification',
    '• Technologies: Python, Scikit-Learn, NLTK, Pandas, Matplotlib',
    '• Implemented advanced feature extraction and text preprocessing techniques',
    '• Created intuitive web interface for real-time spam detection',
    '',
    'Real-time Sentiment Analysis Application',
    '• Built comprehensive sentiment analysis tool for social media data processing',
    '• Technologies: Python, LSTM Networks, TensorFlow, Flask, React',
    '• Achieved 88% accuracy on diverse text datasets with real-time processing',
    '• Deployed scalable solution with REST API integration',
    '',
    'Software Behavior Prediction System',
    '• Created predictive model for software performance analysis and optimization',
    '• Technologies: Python, Random Forest, XGBoost, Data Visualization',
    '• Improved prediction accuracy by 35% over baseline models',
    '• Implemented comprehensive dashboard for performance monitoring',
    '',
    'AI-Powered Portfolio Website',
    '• Developed responsive portfolio with modern UI/UX design principles',
    '• Technologies: React, TypeScript, Tailwind CSS, Framer Motion',
    '• Integrated AI features and interactive elements for enhanced user experience'
  ]);

  // Achievements & Certifications
  addSection('ACHIEVEMENTS & CERTIFICATIONS', [
    'Professional Certifications:',
    '• AI & Machine Learning Certification - Microsoft/SAP AICTE TechSaksham',
    '• Advanced Python Programming Certification - APSSDC',
    '• Data Science Fundamentals - Coursera (Google)',
    '• Prompt Engineering for AI Applications - Smart Intern',
    '',
    'Academic Achievements:',
    '• Consistently maintained high academic performance (7.65+ CGPA)',
    '• Active participant in technical workshops and AI conferences',
    '• Regular contributor to open-source AI projects',
    '• Published research on AI applications in software engineering'
  ]);

  // Research & Publications
  addSection('RESEARCH INTERESTS', [
    'Areas of Focus:',
    '• Generative AI and Large Language Models',
    '• Prompt Engineering and AI Optimization',
    '• Natural Language Processing Applications',
    '• Machine Learning in Software Engineering',
    '• Computer Vision and Image Processing',
    '',
    'Current Research:',
    '• Investigating advanced prompt engineering techniques for improved AI responses',
    '• Exploring applications of generative AI in software development workflows',
    '• Developing novel approaches to AI model optimization and performance enhancement'
  ]);

  // Download the PDF
  pdf.save('Palla_Siva_Portfolio_CV.pdf');
};
