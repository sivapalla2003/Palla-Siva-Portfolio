import jsPDF from 'jspdf';

export const generateATSResume = () => {
  const pdf = new jsPDF();
  const pageWidth = pdf.internal.pageSize.width;
  const margin = 20;
  const lineHeight = 6;
  let yPosition = 30;

  // Define colors
  const primaryBlue = '#2563eb';
  const lightBlue = '#dbeafe';
  const darkGray = '#374151';
  const lightGray = '#6b7280';

  // Helper function to add section
  const addSection = (title: string, content: string[], isHeader = false) => {
    // Section header with blue background
    if (!isHeader) {
      pdf.setFillColor(primaryBlue);
      pdf.rect(margin, yPosition - 3, pageWidth - 2 * margin, 8, 'F');
      pdf.setTextColor(255, 255, 255);
      pdf.setFontSize(12);
      pdf.setFont('helvetica', 'bold');
      pdf.text(title, margin + 2, yPosition + 2);
      yPosition += 12;
    }

    // Content
    pdf.setTextColor(darkGray);
    content.forEach((line, index) => {
      if (line.startsWith('•')) {
        pdf.setFont('helvetica', 'normal');
        pdf.setFontSize(10);
        pdf.text(line, margin + 5, yPosition);
      } else if (line.includes('|')) {
        pdf.setFont('helvetica', 'bold');
        pdf.setFontSize(11);
        pdf.text(line, margin, yPosition);
      } else {
        pdf.setFont('helvetica', 'normal');
        pdf.setFontSize(10);
        pdf.text(line, margin, yPosition);
      }
      yPosition += lineHeight;
    });
    yPosition += 5;
  };

  // Header Section
  pdf.setFillColor(lightBlue);
  pdf.rect(0, 0, pageWidth, 50, 'F');
  
  pdf.setTextColor(primaryBlue);
  pdf.setFontSize(20);
  pdf.setFont('helvetica', 'bold');
  pdf.text('YOUR NAME', margin, 20);
  
  pdf.setTextColor(darkGray);
  pdf.setFontSize(12);
  pdf.setFont('helvetica', 'normal');
  pdf.text('Software Engineer | AI & Data Science Specialist', margin, 28);
  
  pdf.setFontSize(10);
  pdf.text('Email: your.email@example.com | Phone: +1-234-567-8900', margin, 35);
  pdf.text('LinkedIn: linkedin.com/in/yourprofile | GitHub: github.com/yourprofile', margin, 42);

  yPosition = 65;

  // Professional Summary
  addSection('PROFESSIONAL SUMMARY', [
    'Recent BTech graduate in Computer Science Engineering (AI & Data Science) with expertise in artificial',
    'intelligence, machine learning, and data analytics. Proven experience in prompt engineering, generative AI,',
    'and Python programming through multiple internships. Strong problem-solving abilities with a passion for',
    'creating innovative AI-driven solutions.'
  ]);

  // Education
  addSection('EDUCATION', [
    'Bachelor of Technology in Computer Science Engineering (AI & Data Science)',
    'Satya Institute of Technology & Management | 2021 - 2025 | GPA: 7.65',
    '',
    'Intermediate (MPC)',
    'Sri Balaji Jr. College | 2018 - 2020 | GPA: 9.46',
    '',
    'Secondary School Certificate',
    'Z.P. High School | 2013 - 2018 | GPA: 9.2'
  ]);

  // Work Experience
  addSection('WORK EXPERIENCE', [
    'AI Prompt Engineer Intern | Smart Intern | Feb 2025 - May 2025',
    '• Built NLP-based tools for content generation using advanced prompt engineering techniques',
    '• Developed comprehensive prompt documentation improving team efficiency by 40%',
    '• Integrated AI models with web applications using OpenAI API and modern frameworks',
    '• Collaborated with cross-functional teams to optimize AI model performance',
    '',
    'AI Intern | Microsoft/SAP AICTE TechSaksham | Dec 2024 - Jan 2025',
    '• Participated in advanced AI training programs led by industry professionals',
    '• Worked on machine learning projects using Microsoft Azure and SAP technologies',
    '• Gained hands-on experience with cloud AI services and enterprise solutions',
    '• Developed technical skills in cloud computing and AI implementation',
    '',
    'AI & ML Intern | APSSDC / Edunet | May 2024 - June 2024',
    '• Developed spam detection systems achieving 90%+ accuracy using machine learning algorithms',
    '• Built sentiment analysis models using LSTM, SVM, and Random Forest techniques',
    '• Implemented end-to-end ML pipelines with Python and Scikit-Learn',
    '• Analyzed large datasets and created data visualization dashboards'
  ]);

  // Check if we need a new page
  if (yPosition > 250) {
    pdf.addPage();
    yPosition = 30;
  }

  // Technical Skills
  addSection('TECHNICAL SKILLS', [
    'Programming Languages: Python, JavaScript, TypeScript, SQL',
    'AI/ML Technologies: TensorFlow, PyTorch, Scikit-Learn, OpenAI API, Hugging Face',
    'Web Technologies: React, Node.js, HTML5, CSS3, Tailwind CSS',
    'Databases: MongoDB, PostgreSQL, MySQL',
    'Cloud Platforms: Microsoft Azure, AWS',
    'Tools & Technologies: Git, Docker, Jupyter Notebooks, VS Code',
    'Specializations: Prompt Engineering, NLP, Computer Vision, Data Analytics'
  ]);

  // Projects
  addSection('PROJECTS', [
    'SMS Spam Detection System',
    '• Developed machine learning model for spam detection with 92% accuracy',
    '• Technologies: Python, Scikit-Learn, NLTK, Pandas',
    '• Implemented feature extraction and text preprocessing techniques',
    '',
    'Sentiment Analysis Application',
    '• Built real-time sentiment analysis tool for social media data',
    '• Technologies: Python, LSTM, TensorFlow, Flask',
    '• Achieved 88% accuracy on diverse text datasets',
    '',
    'Software Behavior Prediction',
    '• Created predictive model for software performance analysis',
    '• Technologies: Python, Random Forest, Data Visualization',
    '• Improved prediction accuracy by 35% over baseline models'
  ]);

  // Certifications
  addSection('CERTIFICATIONS', [
    '• AI & Machine Learning Certification - Microsoft/SAP AICTE TechSaksham',
    '• Python Programming Certification - APSSDC',
    '• Data Science Fundamentals - Coursera',
    '• Prompt Engineering for AI - Smart Intern'
  ]);

  return pdf;
};

export const downloadResume = () => {
  // Google Drive direct download link
  const driveLink = 'https://drive.google.com/file/d/1MrFpqXs7YUfJIDpZzR5VnHxSQqNWKBi8/view?usp=drivesdk';
  
  // Open the Google Drive link in a new tab
  window.open(driveLink, '_blank');
};
